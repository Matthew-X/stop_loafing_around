package com.example.stop_loafing_around

import android.net.Uri
import android.text.Editable

class One_step (var description: Editable? = null,var timer:ArrayList<Editable?> = arrayListOf<Editable?>("0".toEditable(),"0".toEditable(),"0".toEditable()),var image: Uri? = null,var load_img:Boolean = false) {
}