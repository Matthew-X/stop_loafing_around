package com.example.stop_loafing_around

import android.net.Uri

class Display_Recipes(var name:String? = null,var image: Uri? = null) {
}